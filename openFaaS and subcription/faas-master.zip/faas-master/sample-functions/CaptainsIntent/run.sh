#!/bin/sh
cat request.json | node handler.js -

pwgen
-----

The password generation utility from Alpine Linux, but as a function.

Man page:

https://linux.die.net/man/1/pwgen



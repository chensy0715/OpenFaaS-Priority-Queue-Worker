#!/bin/sh

echo "Building functions/base:openjdk-8u121-jdk-alpine"
docker build -t functions/base:openjdk-8u121-jdk-alpine .

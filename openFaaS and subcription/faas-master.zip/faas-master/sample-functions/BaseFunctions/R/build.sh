#!/bin/sh

echo "Building functions/base:R-3.4.1-alpine"
docker build -t functions/base:R-3.4.1-alpine .


#!/bin/sh

faas-cli build --parallel 4

## Exploring or editing the Swagger API documentation

The `swagger.yml` file can be viewed and edited in the Swagger UI.

* Head over to the [Swagger editor](http://editor.swagger.io/)

* Now click File -> Import URL

* Type in `https://raw.githubusercontent.com/openfaas/faas/master/api-docs/swagger.yml` and click OK

You can now view and edit the Swagger, copy back to your fork before pushing changes.

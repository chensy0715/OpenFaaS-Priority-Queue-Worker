# Alertmanager for ARMHF

## Building:

```bash
make ci-armhf-build
```

## Pushing:

```bash
make ci-armhf-push
```
